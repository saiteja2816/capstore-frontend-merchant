import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { ShowProductsComponent } from '../show-products/show-products.component';

@Component({
  selector: 'app-product-transfer',
  templateUrl: './product-transfer.component.html',
  styleUrls: ['./product-transfer.component.css']
})
export class ProductTransferComponent implements OnInit {

  constructor(private productService: ProductServiceService,private show: ShowProductsComponent) { }
  productid:number;
  ngOnInit() {
  }

  productTransfer(productid,recproductid,brand)
 { 
this.productService.productTransfer(productid,recproductid,brand).subscribe(data => {
if(data===1)
{
  window.alert('Transfer Successful');
  this.productid=this.show.showProducts(productid);
}
else{
  window.alert('Products Not Transferred.Try Again');
}
 });
}
}
