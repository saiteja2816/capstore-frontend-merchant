import { Component, OnInit, Injector, RootRenderer, Injectable } from '@angular/core';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-show-products',
  templateUrl: './show-products.component.html',
  styleUrls: ['./show-products.component.css']

})
@Injectable({
  providedIn:'root'
})

export class ShowProductsComponent implements OnInit {
   
  products:number;
  constructor(private productService : ProductServiceService) { }

  ngOnInit() {
  }
  showProducts(productid): number
  {
  this.productService.showProducts(productid).subscribe(data=>{
  this.products=data;
  console.log(this.products);  
})
return this.products;
  }
}
