import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

 constructor(private httpClient:HttpClient) { }
 
 public showProducts(productid): Observable<number>
 {
 console.log(productid);
 return this.httpClient.get<number>("http://localhost:9090/user/show/" + productid)
 }

 
 public createProductAccount(userDetails) {
 return this.httpClient.post<Product>("http://localhost:9090/user/add", userDetails);
 }

 public updateProduct(productid,brand): Observable<number>
 {
 console.log(productid);
 let url = 'http://localhost:9090/user/update/'+productid+'/'+brand;
 return this.httpClient.put<number>(url,"");
 }
 
 public deleteProduct(productid,brand): Observable<number>
 {
 console.log(productid);
 let url = 'http://localhost:9090/user/delete/'+productid+'/'+brand;
 return this.httpClient.put<number>(url,"");
 }

 public productTransfer(source,destination,brand): Observable<number>
 {
   let url = 'http://localhost:9090/user/transfer/'+source+'/'+destination+'/'+brand;
   console.log(url);
   return this.httpClient.get<number>(url);
 }
 
 
}

3