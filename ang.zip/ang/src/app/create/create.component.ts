import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  user: Product;
constructor(private productService:ProductServiceService) 
{  this.user =new Product();}
   
  ngOnInit() {
  }

  createProductAccount(productid,category,name,type,subtype,brand,description,price,discount):void {
    this.user.productId=productid; 
    this.user.category=category;
    this.user.name=name;
    this.user.type=type;
    this.user.subtype=subtype;
    this.user.brand=brand;
    this.user.description=description;
    this.user.price=price;
    this.user.discount=discount;

    this.productService.createProductAccount(this.user).subscribe(data => {
    alert("Account created successfully.");
    });
}
}

