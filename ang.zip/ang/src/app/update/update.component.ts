import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { ShowProductsComponent } from '../show-products/show-products.component';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  productid: number;
  constructor(private productService:ProductServiceService,private show: ShowProductsComponent) { }
  ngOnInit() {
  }
  updateProduct(productid,brand){
  this.productService.updateProduct(productid,brand).subscribe(data => {
    if(data===1)
    {
      window.alert('Update Successful');
      this.productid=this.show.showProducts(productid);
    }
    else{
      window.alert('Try Again');
    }
  });
 }
}
