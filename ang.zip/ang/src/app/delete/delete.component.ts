import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../product-service.service';
import { ShowProductsComponent } from '../show-products/show-products.component';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  productid: number;
  constructor(private productService:ProductServiceService,private show: ShowProductsComponent) { }
  ngOnInit() {
  }
  deleteProduct(productid,brand){
  this.productService.deleteProduct(productid,brand).subscribe(data => {
    if(data===1)
{
  window.alert('Delete Successful');
  this.productid=this.show.showProducts(productid);
}
else{
  window.alert('Try Again');
}
  });
 }
}
