export class Product
{
public productId: number;
 public category: string;
 public name:string;
 public type:string;
 public subtype:string;
 public brand:string;
 public description:string
 public price:number;
 public discount:string;
}
